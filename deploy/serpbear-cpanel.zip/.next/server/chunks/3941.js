"use strict";
exports.id = 3941;
exports.ids = [3941];
exports.modules = {

/***/ 3941:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export updateKeywordPosition */
/* harmony import */ var perf_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4074);
/* harmony import */ var perf_hooks__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(perf_hooks__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var timers_promises__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8670);
/* harmony import */ var timers_promises__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(timers_promises__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _scraper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2398);
/* harmony import */ var _parseKeywords__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1010);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_scraper__WEBPACK_IMPORTED_MODULE_2__]);
_scraper__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




/**
 * Refreshes the Keywords position by Scraping Google Search Result by
 * Determining whether the keywords should be scraped in Parallel or not
 * @param {Keyword[]} rawKeyword - Keywords to scrape
 * @param {SettingsType} settings - The App Settings that contain the Scraper settings
 * @param {DomainType[]} domains - Optional domain list for per-domain strategy overrides
 * @returns {Promise}
 */ const refreshAndUpdateKeywords = async (rawKeyword, settings, domains)=>{
    const keywords = rawKeyword.map((el)=>el.get({
            plain: true
        }));
    if (!rawKeyword || rawKeyword.length === 0) {
        return [];
    }
    const start = perf_hooks__WEBPACK_IMPORTED_MODULE_0__.performance.now();
    const updatedKeywords = [];
    if ([
        "scrapingant",
        "serpapi",
        "searchapi"
    ].includes(settings.scraper_type)) {
        const refreshedResults = await refreshParallel(keywords, settings, domains);
        if (refreshedResults.length > 0) {
            for (const keyword of rawKeyword){
                const refreshedKeywordData = refreshedResults.find((k)=>k && k.ID === keyword.ID);
                if (refreshedKeywordData) {
                    const updatedKeyword = await updateKeywordPosition(keyword, refreshedKeywordData, settings);
                    updatedKeywords.push(updatedKeyword);
                }
            }
        }
    } else {
        for (const keyword1 of rawKeyword){
            console.log("START SCRAPE: ", keyword1.keyword);
            const keywordPlain = keyword1.get({
                plain: true
            });
            const domainSettings = domains?.find((d)=>d.domain === keywordPlain.domain);
            const updatedKeyword1 = await refreshAndUpdateKeyword(keyword1, settings, domainSettings);
            updatedKeywords.push(updatedKeyword1);
            if (keywords.length > 0 && settings.scrape_delay && settings.scrape_delay !== "0") {
                await (0,timers_promises__WEBPACK_IMPORTED_MODULE_1__.setTimeout)(parseInt(settings.scrape_delay, 10));
            }
        }
    }
    const end = perf_hooks__WEBPACK_IMPORTED_MODULE_0__.performance.now();
    console.log(`time taken: ${end - start}ms`);
    return updatedKeywords;
};
/**
 * Scrape Serp for given keyword and update the position in DB.
 * @param {Keyword} keyword - Keywords to scrape
 * @param {SettingsType} settings - The App Settings that contain the Scraper settings
 * @param {DomainType} domainSettings - Optional domain-level settings override
 * @returns {Promise<KeywordType>}
 */ const refreshAndUpdateKeyword = async (keyword, settings, domainSettings)=>{
    const currentKeyword = keyword.get({
        plain: true
    });
    const refreshedKeywordData = await (0,_scraper__WEBPACK_IMPORTED_MODULE_2__/* .scrapeKeywordWithStrategy */ .qI)(currentKeyword, settings, domainSettings);
    const updatedKeyword = refreshedKeywordData ? await updateKeywordPosition(keyword, refreshedKeywordData, settings) : currentKeyword;
    return updatedKeyword;
};
/**
 * Processes the scraped data for the given keyword and updates the keyword serp position in DB.
 * @param {Keyword} keywordRaw - Keywords to Update
 * @param {RefreshResult} updatedKeyword - scraped Data for that Keyword
 * @param {SettingsType} settings - The App Settings that contain the Scraper settings
 * @returns {Promise<KeywordType>}
 */ const updateKeywordPosition = async (keywordRaw, updatedKeyword, settings)=>{
    const keywordParsed = (0,_parseKeywords__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)([
        keywordRaw.get({
            plain: true
        })
    ]);
    const keyword = keywordParsed[0];
    // const updatedKeyword = refreshed;
    let updated = keyword;
    if (updatedKeyword && keyword) {
        const newPos = updatedKeyword.position;
        const { history  } = keyword;
        const theDate = new Date();
        const dateKey = `${theDate.getFullYear()}-${theDate.getMonth() + 1}-${theDate.getDate()}`;
        history[dateKey] = newPos;
        const updatedVal = {
            position: newPos,
            updating: false,
            url: updatedKeyword.url,
            lastResult: updatedKeyword.result,
            history,
            lastUpdated: updatedKeyword.error ? keyword.lastUpdated : theDate.toJSON(),
            lastUpdateError: updatedKeyword.error ? JSON.stringify({
                date: theDate.toJSON(),
                error: `${updatedKeyword.error}`,
                scraper: settings.scraper_type
            }) : "false"
        };
        // If failed, Add to Retry Queue Cron
        if (updatedKeyword.error && settings?.scrape_retry) {
            await (0,_scraper__WEBPACK_IMPORTED_MODULE_2__/* .retryScrape */ .Vx)(keyword.ID);
        } else {
            await (0,_scraper__WEBPACK_IMPORTED_MODULE_2__/* .removeFromRetryQueue */ .jW)(keyword.ID);
        }
        // Update the Keyword Position in Database
        try {
            await keywordRaw.update({
                ...updatedVal,
                lastResult: Array.isArray(updatedKeyword.result) ? JSON.stringify(updatedKeyword.result) : updatedKeyword.result,
                history: JSON.stringify(history)
            });
            console.log("[SUCCESS] Updating the Keyword: ", keyword.keyword);
            updated = {
                ...keyword,
                ...updatedVal,
                lastUpdateError: JSON.parse(updatedVal.lastUpdateError)
            };
        } catch (error) {
            console.log("[ERROR] Updating SERP for Keyword", keyword.keyword, error);
        }
    }
    return updated;
};
/**
 * Scrape Google Keyword Search Result in Parallel.
 * @param {KeywordType[]} keywords - Keywords to scrape
 * @param {SettingsType} settings - The App Settings that contain the Scraper settings
 * @param {DomainType[]} domains - Optional domain list for per-domain strategy overrides
 * @returns {Promise}
 */ const refreshParallel = async (keywords, settings, domains)=>{
    const promises = keywords.map((keyword)=>{
        const domainSettings = domains?.find((d)=>d.domain === keyword.domain);
        return (0,_scraper__WEBPACK_IMPORTED_MODULE_2__/* .scrapeKeywordWithStrategy */ .qI)(keyword, settings, domainSettings);
    });
    const results = await Promise.allSettled(promises);
    const fulfilled = results.filter((r)=>r.status === "fulfilled");
    return fulfilled.map((r)=>r.value);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (refreshAndUpdateKeywords);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;