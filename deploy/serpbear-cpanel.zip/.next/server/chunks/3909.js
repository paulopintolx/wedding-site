"use strict";
exports.id = 3909;
exports.ids = [3909];
exports.modules = {

/***/ 3909:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _services_scrapingant__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5143);
/* harmony import */ var _services_scrapingrobot__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8763);
/* harmony import */ var _services_serpapi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6);
/* harmony import */ var _services_serply__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1529);
/* harmony import */ var _services_spaceserp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3035);
/* harmony import */ var _services_proxy__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9619);
/* harmony import */ var _services_searchapi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3410);
/* harmony import */ var _services_valueserp__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5281);
/* harmony import */ var _services_serper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9710);
/* harmony import */ var _services_hasdata__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1291);
/* harmony import */ var _services_crazyserp__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7231);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_proxy__WEBPACK_IMPORTED_MODULE_5__]);
_services_proxy__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([
    _services_scrapingrobot__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
    _services_scrapingant__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z,
    _services_serpapi__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
    _services_serply__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
    _services_spaceserp__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
    _services_proxy__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
    _services_searchapi__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
    _services_valueserp__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
    _services_serper__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
    _services_hasdata__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
    _services_crazyserp__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, 
]);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_countries__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6426);

const googleDomains = {
    GB: "www.google.co.uk",
    CA: "www.google.ca",
    DE: "www.google.de",
    FR: "www.google.fr",
    ES: "www.google.es",
    IT: "www.google.it",
    NL: "www.google.nl"
};
const crazyserp = {
    id: "crazyserp",
    name: "CrazySERP",
    website: "crazyserp.com",
    allowsCity: true,
    nativePagination: true,
    headers: (keyword, settings)=>{
        return {
            "Content-Type": "application/json",
            Authorization: `Bearer ${settings.scaping_api}`
        };
    },
    scrapeURL: (keyword, settings, countryData)=>{
        const country = keyword.country || "US";
        const lang = countryData[country][2];
        const countryName = _utils_countries__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP[country][0];
        const location = keyword.city ? `${keyword.city},${countryName}` : countryName;
        const googleDomain = googleDomains[country] || "www.google.com";
        return `https://crazyserp.com/api/search?q=${encodeURIComponent(keyword.keyword)}&page=10&pageOffset=0&location=${encodeURIComponent(location)}&googleDomain=${googleDomain}&gl=${country.toLowerCase()}&hl=${lang}&safe=off&filter=1&nfpr=0&device=${keyword.device}`;
    },
    resultObjectKey: "parsed_data",
    serpExtractor: (content)=>{
        const extractedResult = [];
        const parsed = typeof content === "string" ? JSON.parse(content) : content;
        const results = parsed.organic || parsed;
        for (const { url , title , position  } of results){
            if (title && url) {
                extractedResult.push({
                    title,
                    url,
                    position
                });
            }
        }
        return extractedResult;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (crazyserp);


/***/ }),

/***/ 1291:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_countries__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6426);

const hasdata = {
    id: "hasdata",
    name: "HasData",
    website: "hasdata.com",
    allowsCity: true,
    headers: (keyword, settings)=>{
        return {
            "Content-Type": "application/json",
            "x-api-key": settings.scaping_api
        };
    },
    scrapeURL: (keyword, settings, _countryData, pagination)=>{
        const country = keyword.country || "US";
        const countryName = _utils_countries__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP[country][0];
        const location = keyword.city && countryName ? `&location=${encodeURIComponent(`${keyword.city},${countryName}`)}` : "";
        const p = pagination || {
            start: 0,
            num: 10
        };
        return `https://api.scrape-it.cloud/scrape/google/serp?q=${encodeURIComponent(keyword.keyword)}${location}&num=${p.num}&start=${p.start}&gl=${country.toLowerCase()}&deviceType=${keyword.device}`;
    },
    resultObjectKey: "organicResults",
    serpExtractor: (content)=>{
        const extractedResult = [];
        const results = typeof content === "string" ? JSON.parse(content) : content;
        for (const { link , title , position  } of results){
            if (title && link) {
                extractedResult.push({
                    title,
                    url: link,
                    position
                });
            }
        }
        return extractedResult;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (hasdata);


/***/ }),

/***/ 9619:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var cheerio__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(295);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([cheerio__WEBPACK_IMPORTED_MODULE_0__]);
cheerio__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const proxy = {
    id: "proxy",
    name: "Proxy",
    website: "",
    resultObjectKey: "data",
    headers: ()=>{
        return {
            Accept: "gzip,deflate,compress;"
        };
    },
    scrapeURL: (keyword, _settings, _countries, pagination)=>{
        const p = pagination || {
            start: 0,
            num: 10
        };
        return `https://www.google.com/search?num=${p.num}&start=${p.start}&q=${encodeURI(keyword.keyword)}`;
    },
    serpExtractor: (content)=>{
        const extractedResult = [];
        const $ = cheerio__WEBPACK_IMPORTED_MODULE_0__.load(content);
        let lastPosition = 0;
        const hasValidContent = $("body").find("#main");
        if (hasValidContent.length === 0) {
            const msg = "[ERROR] Scraped search results from proxy do not adhere to expected format. Unable to parse results";
            console.log(msg);
            throw new Error(msg);
        }
        const mainContent = $("body").find("#main");
        const children = $(mainContent).find("h3");
        for(let index = 0; index < children.length; index += 1){
            const title = $(children[index]).text();
            const url = $(children[index]).closest("a").attr("href");
            const cleanedURL = url ? url.replaceAll(/^.+?(?=https:|$)/g, "").replaceAll(/(&).*/g, "") : "";
            if (title && url) {
                lastPosition += 1;
                extractedResult.push({
                    title,
                    url: cleanedURL,
                    position: lastPosition
                });
            }
        }
        return extractedResult;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (proxy);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5143:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const scrapingAnt = {
    id: "scrapingant",
    name: "ScrapingAnt",
    website: "scrapingant.com",
    headers: (keyword)=>{
        // eslint-disable-next-line max-len
        const mobileAgent = "Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36";
        return keyword && keyword.device === "mobile" ? {
            "Ant-User-Agent": mobileAgent
        } : {};
    },
    scrapeURL: (keyword, settings, countryData, pagination)=>{
        const scraperCountries = [
            "AE",
            "BR",
            "CN",
            "DE",
            "ES",
            "FR",
            "GB",
            "HK",
            "PL",
            "IN",
            "IT",
            "IL",
            "JP",
            "NL",
            "RU",
            "SA",
            "US",
            "CZ"
        ];
        const country = scraperCountries.includes(keyword.country.toUpperCase()) ? keyword.country : "US";
        const lang = countryData[country][2];
        const p = pagination || {
            start: 0,
            num: 10
        };
        const url = encodeURI(`https://www.google.com/search?num=${p.num}&start=${p.start}&hl=${lang}&q=${keyword.keyword}`);
        return `https://api.scrapingant.com/v2/extended?url=${url}&x-api-key=${settings.scaping_api}&proxy_country=${country}&browser=false`;
    },
    resultObjectKey: "result"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (scrapingAnt);


/***/ }),

/***/ 8763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const scrapingRobot = {
    id: "scrapingrobot",
    name: "Scraping Robot",
    website: "scrapingrobot.com",
    scrapeURL: (keyword, settings, countryData, pagination)=>{
        const country = keyword.country || "US";
        const device = keyword.device === "mobile" ? "&mobile=true" : "";
        const lang = countryData[country][2];
        const p = pagination || {
            start: 0,
            num: 10
        };
        const url = encodeURI(`https://www.google.com/search?num=${p.num}&start=${p.start}&hl=${lang}&gl=${country}&q=${keyword.keyword}`);
        return `https://api.scrapingrobot.com/?token=${settings.scaping_api}&proxyCountry=${country}&render=false${device}&url=${url}`;
    },
    resultObjectKey: "result"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (scrapingRobot);


/***/ }),

/***/ 3410:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_countries__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6426);

const searchapi = {
    id: "searchapi",
    name: "SearchApi.io",
    website: "searchapi.io",
    allowsCity: true,
    nativePagination: true,
    headers: (keyword, settings)=>{
        return {
            "Content-Type": "application/json",
            Authorization: `Bearer ${settings.scaping_api}`
        };
    },
    scrapeURL: (keyword)=>{
        const country = keyword.country || "US";
        const countryName = _utils_countries__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP[country][0];
        const location = keyword.city && countryName ? `&location=${encodeURIComponent(`${keyword.city},${countryName}`)}` : "";
        return `https://www.searchapi.io/api/v1/search?engine=google&q=${encodeURIComponent(keyword.keyword)}&num=100&gl=${country}&device=${keyword.device}${location}`;
    },
    resultObjectKey: "organic_results",
    serpExtractor: (content)=>{
        const extractedResult = [];
        const results = typeof content === "string" ? JSON.parse(content) : content;
        for (const { link , title , position  } of results){
            if (title && link) {
                extractedResult.push({
                    title,
                    url: link,
                    position
                });
            }
        }
        return extractedResult;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (searchapi);


/***/ }),

/***/ 6:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_countries__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6426);

const serpapi = {
    id: "serpapi",
    name: "SerpApi.com",
    website: "serpapi.com",
    allowsCity: true,
    nativePagination: true,
    headers: (keyword, settings)=>{
        return {
            "Content-Type": "application/json",
            "X-API-Key": settings.scaping_api
        };
    },
    scrapeURL: (keyword, settings)=>{
        const countryName = _utils_countries__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP[keyword.country || "US"][0];
        const location = keyword.city && keyword.country ? `&location=${encodeURIComponent(`${keyword.city},${countryName}`)}` : "";
        return `https://serpapi.com/search?q=${encodeURIComponent(keyword.keyword)}&num=100&gl=${keyword.country}&device=${keyword.device}${location}&api_key=${settings.scaping_api}`;
    },
    resultObjectKey: "organic_results",
    serpExtractor: (content)=>{
        const extractedResult = [];
        const results = typeof content === "string" ? JSON.parse(content) : content;
        for (const { link , title , position  } of results){
            if (title && link) {
                extractedResult.push({
                    title,
                    url: link,
                    position
                });
            }
        }
        return extractedResult;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (serpapi);


/***/ }),

/***/ 9710:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_countries__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6426);

const serper = {
    id: "serper",
    name: "Serper.dev",
    website: "serper.dev",
    allowsCity: true,
    scrapeURL: (keyword, settings, countryData, pagination)=>{
        const country = keyword.country || "US";
        const countryName = _utils_countries__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP[country][0];
        const location = keyword.city ? `&location=${encodeURIComponent(`${keyword.city},${countryName}`)}` : "";
        const lang = countryData[country][2];
        const p = pagination || {
            start: 0,
            num: 10,
            page: 1
        };
        return `https://google.serper.dev/search?q=${encodeURIComponent(keyword.keyword)}&gl=${country}&hl=${lang}${location}&page=${p.page}&apiKey=${settings.scaping_api}`;
    },
    resultObjectKey: "organic",
    serpExtractor: (content)=>{
        const extractedResult = [];
        const results = typeof content === "string" ? JSON.parse(content) : content;
        for (const { link , title , position  } of results){
            if (title && link) {
                extractedResult.push({
                    title,
                    url: link,
                    position
                });
            }
        }
        return extractedResult;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (serper);


/***/ }),

/***/ 1529:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const scraperCountries = [
    "US",
    "CA",
    "IE",
    "GB",
    "FR",
    "DE",
    "SE",
    "IN",
    "JP",
    "KR",
    "SG",
    "AU",
    "BR"
];
const serply = {
    id: "serply",
    name: "Serply",
    website: "serply.io",
    headers: (keyword, settings)=>{
        const country = scraperCountries.includes(keyword.country.toUpperCase()) ? keyword.country : "US";
        return {
            "Content-Type": "application/json",
            "X-User-Agent": keyword.device === "mobile" ? "mobile" : "desktop",
            "X-Api-Key": settings.scaping_api,
            "X-Proxy-Location": country
        };
    },
    scrapeURL: (keyword, _settings, _countries, pagination)=>{
        const country = scraperCountries.includes(keyword.country.toUpperCase()) ? keyword.country : "US";
        const p = pagination || {
            start: 0,
            num: 10
        };
        return `https://api.serply.io/v1/search/q=${encodeURIComponent(keyword.keyword)}&num=${p.num}&start=${p.start}&hl=${country}`;
    },
    resultObjectKey: "result",
    serpExtractor: (content)=>{
        const extractedResult = [];
        const results = typeof content === "string" ? JSON.parse(content) : content;
        for (const result of results){
            if (result.title && result.link) {
                extractedResult.push({
                    title: result.title,
                    url: result.link,
                    position: result.realPosition
                });
            }
        }
        return extractedResult;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (serply);


/***/ }),

/***/ 3035:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_countries__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6426);

const spaceSerp = {
    id: "spaceSerp",
    name: "Space Serp",
    website: "spaceserp.com",
    allowsCity: true,
    scrapeURL: (keyword, settings, countryData, pagination)=>{
        const country = keyword.country || "US";
        const countryName = _utils_countries__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP[country][0];
        const location = keyword.city ? `&location=${encodeURIComponent(`${keyword.city},${countryName}`)}` : "";
        const device = keyword.device === "mobile" ? "&device=mobile" : "";
        const lang = countryData[country][2];
        const p = pagination || {
            start: 0,
            num: 10,
            page: 1
        };
        return `https://api.spaceserp.com/google/search?apiKey=${settings.scaping_api}&q=${encodeURIComponent(keyword.keyword)}&pageSize=${p.num}&pageNo=${p.page}&gl=${country}&hl=${lang}${location}${device}&resultBlocks=`;
    },
    resultObjectKey: "organic_results",
    serpExtractor: (content)=>{
        const extractedResult = [];
        const results = typeof content === "string" ? JSON.parse(content) : content;
        for (const result of results){
            if (result.title && result.link) {
                extractedResult.push({
                    title: result.title,
                    url: result.link,
                    position: result.position
                });
            }
        }
        return extractedResult;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (spaceSerp);


/***/ }),

/***/ 5281:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_countries__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6426);

const valueSerp = {
    id: "valueserp",
    name: "Value Serp",
    website: "valueserp.com",
    allowsCity: true,
    scrapeURL: (keyword, settings, countryData, pagination)=>{
        const country = keyword.country || "US";
        const countryName = _utils_countries__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP[country][0];
        const location = keyword.city ? `&location=${encodeURIComponent(`${keyword.city},${countryName}`)}` : "";
        const device = keyword.device === "mobile" ? "&device=mobile" : "";
        const lang = countryData[country][2];
        const p = pagination || {
            start: 0,
            num: 10,
            page: 1
        };
        return `https://api.valueserp.com/search?api_key=${settings.scaping_api}&q=${encodeURIComponent(keyword.keyword)}&gl=${country}&hl=${lang}${device}${location}&page=${p.page}&output=json&include_answer_box=false&include_advertiser_info=false`;
    },
    resultObjectKey: "organic_results",
    serpExtractor: (content)=>{
        const extractedResult = [];
        const results = typeof content === "string" ? JSON.parse(content) : content;
        for (const result of results){
            if (result.title && result.link) {
                extractedResult.push({
                    title: result.title,
                    url: result.link,
                    position: result.position
                });
            }
        }
        return extractedResult;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (valueSerp);


/***/ })

};
;