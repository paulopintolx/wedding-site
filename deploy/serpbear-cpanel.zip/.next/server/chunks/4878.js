"use strict";
exports.id = 4878;
exports.ids = [4878];
exports.modules = {

/***/ 4878:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler),
/* harmony export */   "getAppSettings": () => (/* binding */ getAppSettings)
/* harmony export */ });
/* harmony import */ var fs_promises__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3292);
/* harmony import */ var fs_promises__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs_promises__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var cryptr__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6607);
/* harmony import */ var cryptr__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(cryptr__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4558);
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_config__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_verifyUser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5527);
/* harmony import */ var _scrapers_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3909);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_scrapers_index__WEBPACK_IMPORTED_MODULE_4__]);
_scrapers_index__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





async function handler(req, res) {
    const authorized = (0,_utils_verifyUser__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(req, res);
    if (authorized !== "authorized") {
        return res.status(401).json({
            error: authorized
        });
    }
    if (req.method === "GET") {
        return getSettings(req, res);
    }
    if (req.method === "PUT") {
        return updateSettings(req, res);
    }
    return res.status(502).json({
        error: "Unrecognized Route."
    });
}
const getSettings = async (req, res)=>{
    const settings = await getAppSettings();
    if (settings) {
        const { publicRuntimeConfig  } = next_config__WEBPACK_IMPORTED_MODULE_2___default()();
        const version = publicRuntimeConfig?.version;
        return res.status(200).json({
            settings: {
                ...settings,
                version
            }
        });
    }
    return res.status(400).json({
        error: "Error Loading Settings!"
    });
};
const updateSettings = async (req, res)=>{
    const { settings  } = req.body || {};
    // console.log('### settings: ', settings);
    if (!settings) {
        return res.status(200).json({
            error: "Settings Data not Provided!"
        });
    }
    try {
        const cryptr = new (cryptr__WEBPACK_IMPORTED_MODULE_1___default())(process.env.SECRET);
        const scaping_api = settings.scaping_api ? cryptr.encrypt(settings.scaping_api.trim()) : "";
        const smtp_password = settings.smtp_password ? cryptr.encrypt(settings.smtp_password.trim()) : "";
        const search_console_client_email = settings.search_console_client_email ? cryptr.encrypt(settings.search_console_client_email.trim()) : "";
        const search_console_private_key = settings.search_console_private_key ? cryptr.encrypt(settings.search_console_private_key.trim()) : "";
        const adwords_client_id = settings.adwords_client_id ? cryptr.encrypt(settings.adwords_client_id.trim()) : "";
        const adwords_client_secret = settings.adwords_client_secret ? cryptr.encrypt(settings.adwords_client_secret.trim()) : "";
        const adwords_developer_token = settings.adwords_developer_token ? cryptr.encrypt(settings.adwords_developer_token.trim()) : "";
        const adwords_account_id = settings.adwords_account_id ? cryptr.encrypt(settings.adwords_account_id.trim()) : "";
        const securedSettings = {
            ...settings,
            scaping_api,
            smtp_password,
            search_console_client_email,
            search_console_private_key,
            adwords_client_id,
            adwords_client_secret,
            adwords_developer_token,
            adwords_account_id
        };
        await (0,fs_promises__WEBPACK_IMPORTED_MODULE_0__.writeFile)(`${process.cwd()}/data/settings.json`, JSON.stringify(securedSettings), {
            encoding: "utf-8"
        });
        return res.status(200).json({
            settings
        });
    } catch (error) {
        console.log("[ERROR] Updating App Settings. ", error);
        return res.status(200).json({
            error: "Error Updating Settings!"
        });
    }
};
const safeReadJSON = async (filePath, fallback)=>{
    try {
        const raw = await (0,fs_promises__WEBPACK_IMPORTED_MODULE_0__.readFile)(filePath, {
            encoding: "utf-8"
        });
        return raw ? JSON.parse(raw) : fallback;
    } catch (error) {
        const fileExists = await (0,fs_promises__WEBPACK_IMPORTED_MODULE_0__.stat)(filePath).then(()=>true).catch(()=>false);
        if (fileExists) {
            // File exists but is corrupt — back it up instead of silently overwriting
            const backupPath = `${filePath}.${Date.now()}.corrupt`;
            console.log(`[WARN] Corrupt JSON detected in ${filePath}. Backing up to ${backupPath}`);
            await (0,fs_promises__WEBPACK_IMPORTED_MODULE_0__.rename)(filePath, backupPath).catch(()=>{});
        }
        await (0,fs_promises__WEBPACK_IMPORTED_MODULE_0__.writeFile)(filePath, JSON.stringify(fallback), {
            encoding: "utf-8"
        }).catch(()=>{});
        return fallback;
    }
};
const getAppSettings = async ()=>{
    const screenshotAPIKey = process.env.SCREENSHOT_API || "69408-serpbear";
    const defaultSettings = {
        scraper_type: "none",
        notification_interval: "never",
        notification_email: "",
        notification_email_from: "",
        notification_email_from_name: "SerpBear",
        smtp_server: "",
        smtp_port: "",
        smtp_username: "",
        smtp_password: "",
        scrape_retry: false,
        screenshot_key: screenshotAPIKey,
        search_console: true,
        search_console_client_email: "",
        search_console_private_key: "",
        keywordsColumns: [
            "Best",
            "History",
            "Volume",
            "Search Console"
        ],
        scrape_strategy: "basic",
        scrape_pagination_limit: 5,
        scrape_smart_full_fallback: false
    };
    const settings = await safeReadJSON(`${process.cwd()}/data/settings.json`, defaultSettings);
    const failedQueue = await safeReadJSON(`${process.cwd()}/data/failed_queue.json`, []);
    let decryptedSettings = settings;
    try {
        const cryptr = new (cryptr__WEBPACK_IMPORTED_MODULE_1___default())(process.env.SECRET);
        const scaping_api = settings.scaping_api ? cryptr.decrypt(settings.scaping_api) : "";
        const smtp_password = settings.smtp_password ? cryptr.decrypt(settings.smtp_password) : "";
        const search_console_client_email = settings.search_console_client_email ? cryptr.decrypt(settings.search_console_client_email) : "";
        const search_console_private_key = settings.search_console_private_key ? cryptr.decrypt(settings.search_console_private_key) : "";
        const adwords_client_id = settings.adwords_client_id ? cryptr.decrypt(settings.adwords_client_id) : "";
        const adwords_client_secret = settings.adwords_client_secret ? cryptr.decrypt(settings.adwords_client_secret) : "";
        const adwords_developer_token = settings.adwords_developer_token ? cryptr.decrypt(settings.adwords_developer_token) : "";
        const adwords_account_id = settings.adwords_account_id ? cryptr.decrypt(settings.adwords_account_id) : "";
        decryptedSettings = {
            ...settings,
            scaping_api,
            smtp_password,
            search_console_client_email,
            search_console_private_key,
            search_console_integrated: !!(process.env.SEARCH_CONSOLE_PRIVATE_KEY && process.env.SEARCH_CONSOLE_CLIENT_EMAIL) || !!(search_console_client_email && search_console_private_key),
            available_scrapers: _scrapers_index__WEBPACK_IMPORTED_MODULE_4__/* ["default"].map */ .Z.map((scraper)=>({
                    label: scraper.name,
                    value: scraper.id,
                    allowsCity: !!scraper.allowsCity
                })),
            failed_queue: failedQueue,
            screenshot_key: screenshotAPIKey,
            adwords_client_id,
            adwords_client_secret,
            adwords_developer_token,
            adwords_account_id,
            scrape_strategy: settings.scrape_strategy || "basic",
            scrape_pagination_limit: settings.scrape_pagination_limit || 5,
            scrape_smart_full_fallback: settings.scrape_smart_full_fallback || false
        };
    } catch (error) {
        console.log("Error Decrypting Settings API Keys!");
    }
    return decryptedSettings;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;