// Arranque do SerpBear no cPanel (Passenger).
// Lê as definições de .env.local (criado no servidor, não vai para o GitHub) e arranca o servidor Next.js.
process.chdir(__dirname);
require('dotenv').config({ path: __dirname + '/.env.local' });
require('fs').mkdirSync(__dirname + '/data', { recursive: true });
require('./server.js');
